﻿using System.ComponentModel.DataAnnotations;

namespace TaskManagement.Model
{
    public class TaskModel
    {
        public int TaskId { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Task Name is required.")]
        public string TaskName { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string TaskDescription { get; set; } = string.Empty;

        public int TaskStatusId { get; set; }

        [Display(Name = "Status")]
        public string StatusName { get; set; } = string.Empty;
    }
}
