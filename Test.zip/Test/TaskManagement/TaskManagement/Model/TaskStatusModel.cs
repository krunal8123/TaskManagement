﻿namespace TaskManagement.Model
{
    public class TaskStatusModel
    {
        public int ID { get; set; }
        public string StatusName { get; set; } = "";
    }
}
