﻿using Dapper;
using System.Data;
using TaskManagement.Data;
using TaskManagement.Model;

namespace TaskManagement.Repository
{
    public class TaskRepository : ITaskRepository
    {
        private readonly DapperContext context;

        public TaskRepository()
        {
            this.context = new DapperContext();
        }

        public async Task<List<TaskModel>> GetTaskList()
        {
            try
            {
                using (var connection = context.CreateConnection())
                {
                    var tasks = await connection.QueryAsync<TaskModel>("sp_SelectAllTasks", commandType: CommandType.StoredProcedure);
                    return tasks.ToList();
                }
            }
            catch (Exception ex)
            {
                throw new TaskManagementException("Error while retrieving the task list.", ex);
            }
        }

        public async Task<TaskModel> GetTask(int id)
        {
            return new TaskModel();
        }
        public async Task AddTask(TaskModel task)
        {
            var parameters = new
            {
                TaskName = task.TaskName,
                TaskDescription = task.TaskDescription,
                TaskStatusId = task.TaskStatusId
            };
            try
            {
                using (var connection = context.CreateConnection())
                {
                    await connection.ExecuteAsync("sp_AddTask", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw new TaskManagementException("Error while Adding the task.", ex);
            }
        }
        public List<TaskStatusModel> GetTaskStatuses()
        {
            var query = "EXEC sp_GetAllStatuses";
            try
            {
                using (var connection = context.CreateConnection())
                {
                    var statuses = connection.Query<TaskStatusModel>(query).ToList();
                    return statuses;
                }
            }
            catch (Exception ex)
            {
                throw new TaskManagementException("Error while Getting the Statuses.", ex);
            }
        }
        public async Task DeleteTask(int id)
        {
            var parameters = new
            {
                TaskId = id
            };
            try
            {
                using (var connection = context.CreateConnection())
                {
                    await connection.ExecuteAsync("sp_DeleteTask", parameters, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw new TaskManagementException("Error while Deleting the Status.", ex);
            }

        }
        public bool IsTaskNameDuplicated(string taskName)
        {
            try
            {
                using (var connection = context.CreateConnection())
                {
                    var count = connection.ExecuteScalar<int>("sp_IsTaskNameDuplicated", new { TaskName = taskName },
                                                              commandType: CommandType.StoredProcedure);
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                throw new TaskManagementException("Error while Checking the name duplication", ex);
            }

        }

    }
}
