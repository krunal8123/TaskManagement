﻿using TaskManagement.Model;

namespace TaskManagement.Repository
{
    public interface ITaskRepository
    {
        Task<List<TaskModel>> GetTaskList();
        Task<TaskModel> GetTask(int id);
        Task AddTask(TaskModel task);
        Task DeleteTask(int id);
        List<TaskStatusModel> GetTaskStatuses();
        bool IsTaskNameDuplicated(string taskName);
    }
}
