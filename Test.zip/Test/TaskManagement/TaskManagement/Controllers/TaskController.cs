﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using TaskManagement.Model;
using TaskManagement.Repository;

namespace TaskManagement.Controllers
{
    public class TaskController : Controller
    {
        private readonly ITaskRepository _taskRepository;

        public TaskController(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        [HttpGet]
        public async Task<ActionResult> Index()
        {
            var list = await _taskRepository.GetTaskList(); // Fetch all Tasks from Repo
            return View(list);
        }
        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.Statuses = GetTaskStatuses(); // Fetch task statuses from the repository
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Create(TaskModel task)
        {
            if (ModelState.IsValid)
            {
                await _taskRepository.AddTask(task);
                return RedirectToAction("Index");
            }
            ViewBag.Statuses = GetTaskStatuses();
            return View(task);
        }
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            var task = await _taskRepository.GetTask(id);
            if (task == null)
            {
                return NotFound();
            }
            else
            {
                await _taskRepository.DeleteTask(id); // Delete the Task from Repo
                return RedirectToAction("Index");
            }
        }
        [HttpGet]
        public IActionResult CheckTaskNameDuplicacy(string taskName)
        {
            var isDuplicate = _taskRepository.IsTaskNameDuplicated(taskName);
            return Json(new { isDuplicate });
        }

        private IEnumerable<SelectListItem> GetTaskStatuses()
        {
            var taskStatuses = _taskRepository.GetTaskStatuses();
            var selectList = taskStatuses.Select(status => new SelectListItem
            {
                Value = status.ID.ToString(),
                Text = status.StatusName
            });

            return selectList;
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
