using Microsoft.AspNetCore.Diagnostics;
using TaskManagement.Model;
using TaskManagement.Repository;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();

//builder.Services.AddTransient<IDapperContext, DapperContext>();
builder.Services.AddTransient<ITaskRepository, TaskRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler(errorApp =>
    {
        errorApp.Run(async context =>
        {
            var exceptionHandlerPathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
            var exception = exceptionHandlerPathFeature.Error;

            // Log the exception here if necessary.
            // You can also customize the response based on the exception type.

            // For specific custom exceptions, you can check the type and respond accordingly.
            if (exception is TaskManagementException)
            {
                // Handle the custom TaskManagementException.
                context.Response.StatusCode = 500; // Set appropriate status code.
                await context.Response.WriteAsync("An error occurred while processing the request.");
            }
            else
            {
                // For other unhandled exceptions, use the default error handling behavior.
                context.Response.StatusCode = 500; // Set appropriate status code.
                await context.Response.WriteAsync("An unexpected error occurred.");
            }
        });
    });

    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(name: "default",
    pattern: "{controller=Task}/{action=Index}/{id?}");

app.Run();
