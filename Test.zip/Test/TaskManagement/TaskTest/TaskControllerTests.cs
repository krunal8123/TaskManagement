using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using TaskManagement.Controllers;
using TaskManagement.Model;
using TaskManagement.Repository;

namespace TaskManagement.Tests
{
    [TestClass]
    public class TaskControllerTests
    {
        [TestMethod]
        public async Task Index_ReturnsViewWithTaskList()
        {
            // Arrange
            var mockRepository = new Mock<ITaskRepository>();
            var expectedTasks = new List<TaskModel>
            {
                new TaskModel { TaskId = 1, TaskName = "Task 1" },
                new TaskModel { TaskId = 2, TaskName = "Task 2" }
            };
            mockRepository.Setup(repo => repo.GetTaskList()).ReturnsAsync(expectedTasks);
            var controller = new TaskController(mockRepository.Object);

            // Act
            var result = await controller.Index();

            // Assert
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as List<TaskModel>;
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(model);
            Assert.AreEqual(expectedTasks.Count, model.Count);
        }

        [TestMethod]
        public async Task Create_Post_ValidModelState_RedirectsToIndex()
        {
            // Arrange
            var mockRepository = new Mock<ITaskRepository>();
            var controller = new TaskController(mockRepository.Object);
            var taskModel = new TaskModel
            {
                TaskName = "New Task",
                TaskDescription = "Description",
                TaskStatusId = 1
            };

            // Act
            var result = await controller.Create(taskModel);

            // Assert
            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            Assert.AreEqual("Index", redirectToActionResult.ActionName);
            mockRepository.Verify(repo => repo.AddTask(taskModel), Times.Once);
        }

        [TestMethod]
        public async Task Delete_ExistingTask_RedirectsToIndex()
        {
            // Arrange
            var mockRepository = new Mock<ITaskRepository>();
            var controller = new TaskController(mockRepository.Object);
            var taskId = 1;
            mockRepository.Setup(repo => repo.GetTask(taskId)).ReturnsAsync(new TaskModel());

            // Act
            var result = await controller.Delete(taskId);

            // Assert
            var redirectToActionResult = result as RedirectToActionResult;
            Assert.IsNotNull(redirectToActionResult);
            Assert.AreEqual("Index", redirectToActionResult.ActionName);
            mockRepository.Verify(repo => repo.DeleteTask(taskId), Times.Once);
        }

        [TestMethod]
        public async Task Delete_NonExistingTask_ReturnsNotFound()
        {
            // Arrange
            var mockRepository = new Mock<ITaskRepository>();
            var controller = new TaskController(mockRepository.Object);
            var taskId = 1;
            mockRepository.Setup(repo => repo.GetTask(taskId)).ReturnsAsync((TaskModel)null);

            // Act
            var result = await controller.Delete(taskId);

            // Assert
            Assert.IsInstanceOfType(result, typeof(NotFoundResult));
            mockRepository.Verify(repo => repo.DeleteTask(taskId), Times.Never);
        }

    }
}
